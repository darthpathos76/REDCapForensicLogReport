<?php
namespace ForetellLite;

trait AlertsTrait
{
    /**
     * Main runtime alert digest engine. Safe for standard CRON execution blocks.
     * @return void
     */
    public function sendAlertDigest(): void
    {
        try {
            if (!$this->getSystemSetting('alert_email_enabled')) {
                return;
            }

            $recipient = trim((string)$this->getSystemSetting('alert_email'));
            if ($recipient === '') {
                return;
            }

            // Enforce cooling periods
            $cooldown = (int)$this->getSystemSetting('alert_cooldown_minutes');
            if ($cooldown <= 0) {
                $cooldown = 60;
            }

            $lastSent = (int)$this->getSystemSetting('last_alert_sent_ts');
            if (time() - $lastSent < ($cooldown * 60)) {
                return;
            }

            $alertSev = (string)$this->getSystemSetting('alert_min_severity');
            if (!in_array($alertSev, ['low', 'medium', 'high'], true)) {
                $alertSev = 'high';
            }
            $alerts = $this->collectHighPriorityAlerts($alertSev);

            if (empty($alerts)) {
                return;
            }

            $subject = "[ForeTELL Lite] Security Alert Digest";
            $body = "The following high-priority security events were detected:\n\n";

            foreach ($alerts as $a) {
                $body .= strtoupper((string)$a['severity']) . ": " . (string)$a['message'] . "\n";
            }

            $body .= "\nTimestamp: " . date('Y-m-d H:i:s');

            if (class_exists('\\REDCap')) {
                \REDCap::email($recipient, 'no-reply@redcap.local', $subject, nl2br($body));
            }

            $this->setSystemSetting('last_alert_sent_ts', time());

        } catch (\Throwable $e) {
            error_log('[ForeTELL Lite] sendAlertDigest error: ' . $e->getMessage());
        }
    }
}