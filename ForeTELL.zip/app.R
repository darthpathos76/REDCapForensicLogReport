library(shiny)
library(shinydashboard)
library(DBI)
library(duckdb)
library(ggplot2)
library(DT)
library(plotly)

# -------------------------------------------------------------------------
# GLOBAL CONFIGURATION
# -------------------------------------------------------------------------
db_path <- "C:/REDCapLogForensic/REDCap_Forensics.duckdb"

# -------------------------------------------------------------------------
# USER INTERFACE (UI)
# -------------------------------------------------------------------------
ui <- dashboardPage(
  skin = "red",
  dashboardHeader(title = "REDCap Forensic Intelligence Dashboard", titleWidth = 380),
  
  dashboardSidebar(
    width = 380,
    sidebarMenu(
      id = "sidebar_tabs",
      
      menuItem("Today's Urgent Red Flags", tabName = "tab_alerts", icon = icon("radiation", class = "text-danger")),
      menuItem("User Traffic & Security Logs", tabName = "tab_logs", icon = icon("user-shield")),
      menuItem("HTTP Traffic & Server Status", tabName = "tab_http", icon = icon("server")),
      menuItem("Data Downloads & Exports", tabName = "tab_exports", icon = icon("download")),
      menuItem("Exfiltration Threat Matrix", tabName = "tab_exfil", icon = icon("skull-crossbones")),
      menuItem("Geo-Velocity (Impossible Travel)", tabName = "tab_velocity", icon = icon("globe-americas")),
      menuItem("Temporal & Off-Hours Anomalies", tabName = "tab_temporal", icon = icon("clock")),
      menuItem("Session Integrity & API Abuse", tabName = "tab_sessions", icon = icon("key")),
      menuItem("System Alerts Sent", tabName = "tab_alerts_sent", icon = icon("envelope-open-text")),
      menuItem("System Error Monitoring", tabName = "tab_errors", icon = icon("exclamation-triangle")),
      
      hr(),
      div(style = "padding: 15px;",
          dateRangeInput("date_range", "Global Analysis Window:",
                         start = NULL, end = NULL,
                         min = "2023-01-01", max = "2030-12-31")
      )
    )
  ),
  
  dashboardBody(
    tags$head(tags$style(HTML("
      .content-wrapper, .right-side { background-color: #f4f6f9; }
      .box { border-radius: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
      .small-box h3 { font-size: 28px; }
    "))),
    
    tabItems(
      
      # -------------------------------------------------------------------
      # TAB: TODAY'S URGENT ALERTS
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_alerts",
              fluidRow(
                box(
                  title = span(icon("exclamation-triangle"), " ACTIVE DAY-ZERO FORENSIC ALERTS (SINCE MIDNIGHT TODAY)"),
                  status = "danger", solidHeader = TRUE, width = 12,
                  helpText("This live analytical framework aggregates urgent security anomalies that require immediate admin isolation or account locking protocol execution."),
                  dataTableOutput("dt_urgent_alerts")
                )
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: LOGS
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_logs",
              fluidRow(
                valueBoxOutput("box_total_transactions", width = 3),
                valueBoxOutput("box_unique_users", width = 3),
                valueBoxOutput("box_unique_ips", width = 3),
                valueBoxOutput("box_security_alerts", width = 3)
              ),
              
              fluidRow(
                box(title = "REDCap Audit Logs Timeline Activity (Hover for Details)", status = "primary", solidHeader = TRUE, width = 12,
                    plotlyOutput("plot_log_timeline", height = "280px"))
              ),
              
              fluidRow(
                box(title = "Top Web & Script Interactions (Page Views)", status = "success", solidHeader = TRUE, width = 6,
                    plotOutput("plot_user_events", height = "320px")),
                box(title = "Most Active User Accounts (Transactions)", status = "info", solidHeader = TRUE, width = 6,
                    plotOutput("plot_top_users", height = "320px"))
              ),
              
              fluidRow(
                box(title = "Potential Brute Force Authentication Anomalies (Repeated index.php Hits)", status = "danger", solidHeader = TRUE, width = 6,
                    plotOutput("plot_brute_force", height = "320px")),
                box(title = "High-Volume Project Activity (Project-Specific Spikes)", status = "warning", solidHeader = TRUE, width = 6,
                    plotOutput("plot_project_activity", height = "320px"))
              ),
              
              fluidRow(
                box(title = "Unified Forensic Transaction Ledger", status = "primary", solidHeader = TRUE, width = 12,
                    dataTableOutput("dt_unified_logs"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: HTTP TRAFFIC
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_http",
              fluidRow(
                box(title = "Estimated Transaction Status Distribution", status = "primary", solidHeader = TRUE, width = 6,
                    plotOutput("plot_http_codes", height = "320px")),
                box(title = "Suspect Request Methods or Probing Actions", status = "danger", solidHeader = TRUE, width = 6,
                    plotOutput("plot_http_methods", height = "320px"))
              ),
              
              fluidRow(
                box(title = "High-Risk Threat Matrix: Top Suspicious Source IPs (Excludes Pen-Tester & Internal Subnets)", status = "warning", solidHeader = TRUE, width = 12,
                    dataTableOutput("dt_suspicious_ips"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: EXPORTS
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_exports",
              fluidRow(
                box(title = "Data Export Volumes Timeline (Hover for Details)", status = "info", solidHeader = TRUE, width = 12,
                    plotlyOutput("plot_export_timeline", height = "260px"))
              ),
              
              fluidRow(
                box(title = "Audited Document, PDF, and Dataset Downloads Ledger", status = "info", solidHeader = TRUE, width = 12,
                    dataTableOutput("dt_downloads_ledger"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: EXFILTRATION
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_exfil",
              fluidRow(
                box(title = "High-Risk Volume Outliers (Top Targets by Event Count)", status = "danger", solidHeader = TRUE, width = 12,
                    plotOutput("plot_exfil_outliers", height = "280px"))
              ),
              
              fluidRow(
                box(title = "Potential Data Exfiltration / Massive Extraction Watchlist", status = "danger", solidHeader = TRUE, width = 12,
                    dataTableOutput("dt_exfil_matrix"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: IMPOSSIBLE TRAVEL
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_velocity",
              fluidRow(
                box(title = "Impossible Travel & Rapid Subnet Shifts Log", status = "danger", solidHeader = TRUE, width = 12,
                    p("Flags users shifting IP addresses in less than 1 hour. This indicates probable credential sharing or session hijacking."),
                    dataTableOutput("dt_impossible_travel"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: TEMPORAL ANALYSIS
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_temporal",
              fluidRow(
                box(title = "Transactions by Hour of Day", status = "warning", solidHeader = TRUE, width = 6,
                    plotOutput("plot_hourly_distribution", height = "300px")),
                box(title = "Transactions by Day of Week", status = "warning", solidHeader = TRUE, width = 6,
                    plotOutput("plot_daily_distribution", height = "300px"))
              ),
              
              fluidRow(
                box(title = "High-Risk Dark Hour Transactions (10 PM - 5 AM or Weekends)", status = "danger", solidHeader = TRUE, width = 12,
                    dataTableOutput("dt_dark_hours_ledger"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: SESSIONS
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_sessions",
              fluidRow(
                box(title = "High-Velocity API Token & Scraper Profiling", status = "primary", solidHeader = TRUE, width = 6,
                    p("Identifies automated accounts processing high-frequency data operations bypassing the standard UI."),
                    dataTableOutput("dt_api_velocity")),
                box(title = "Concurrent Session Token Violations", status = "danger", solidHeader = TRUE, width = 6,
                    p("Identifies accounts operating under multiple distinct Session tokens inside a narrow window."),
                    dataTableOutput("dt_concurrent_sessions"))
              ),
              
              fluidRow(
                box(title = "Privilege Escalation & Honey-Pot Reconnaissance Probing", status = "danger", solidHeader = TRUE, width = 12,
                    p("Flags non-admin user accounts attempting to map or request sensitive ControlCenter or backend module URLs."),
                    dataTableOutput("dt_honeypot_probing"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: ALERTS SENT
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_alerts_sent",
              fluidRow(
                box(title = "Triggered Alert Rule Trends", status = "success", solidHeader = TRUE, width = 6,
                    plotOutput("plot_alert_trends", height = "300px")),
                box(title = "Most Targeted Notification Destinations", status = "warning", solidHeader = TRUE, width = 6,
                    plotOutput("plot_alert_targets", height = "300px"))
              ),
              
              fluidRow(
                box(title = "Automated Alerts Sent Ledger", status = "success", solidHeader = TRUE, width = 12,
                    dataTableOutput("dt_alert_logs"))
              )
      ),
      
      # -------------------------------------------------------------------
      # TAB: ERRORS
      # -------------------------------------------------------------------
      tabItem(tabName = "tab_errors",
              fluidRow(
                box(title = "Fatal Script & PHP Exception Frequency (Hover for Details)", status = "danger", solidHeader = TRUE, width = 12,
                    plotlyOutput("plot_error_trends", height = "280px"))
              ),
              
              fluidRow(
                box(title = "System Error Diagnostics Ledger", status = "danger", solidHeader = TRUE, width = 12,
                    dataTableOutput("dt_error_logs"))
              )
      )
    )
  )
)

# -------------------------------------------------------------------------
# SERVER BACKEND
# -------------------------------------------------------------------------
server <- function(input, output, session) {
  
  # ============================================================
  # TIMELINE AUTO-ADJUSTMENT
  # ============================================================
  observe({
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    on.exit(dbDisconnect(con_temp, shutdown = TRUE))
    
    if (dbExistsTable(con_temp, "redcap_log_view")) {
      bounds <- dbGetQuery(con_temp, "
        SELECT
          MIN(CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS DATE)) AS min_ts,
          MAX(CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS DATE)) AS max_ts
        FROM redcap_log_view
        WHERE ts IS NOT NULL AND ts <> ''
      ")
      
      if (!is.na(bounds$min_ts) && !is.na(bounds$max_ts)) {
        updateDateRangeInput(
          session, "date_range",
          start = bounds$max_ts - 7,
          end   = bounds$max_ts,
          min   = bounds$min_ts,
          max   = bounds$max_ts
        )
      }
    }
  })
  
  # ============================================================
  # QUERY WRAPPER
  # ============================================================
  run_query <- function(sql_string) {
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    on.exit(dbDisconnect(con_temp, shutdown = TRUE))
    dbGetQuery(con_temp, sql_string)
  }
  
  # ============================================================
  # CLEAN UNIFIED LOG FILTER (Returns clean WHERE syntax)
  # ============================================================
  unified_log_filter <- reactive({
    req(input$date_range)
    sprintf("
      WHERE CAST(strptime(ts, '%%Y-%%m-%%d %%H:%%M:%%S') AS DATE) >= '%s'
        AND CAST(strptime(ts, '%%Y-%%m-%%d %%H:%%M:%%S') AS DATE) <= '%s'
    ", input$date_range[1], input$date_range[2])
  })
  
  alert_log_filter <- reactive({
    req(input$date_range)
    sprintf("
      WHERE CAST(strptime(time_sent, '%%Y-%%m-%%d %%H:%%M:%%S') AS DATE) >= '%s'
        AND CAST(strptime(time_sent, '%%Y-%%m-%%d %%H:%%M:%%S') AS DATE) <= '%s'
    ", input$date_range[1], input$date_range[2])
  })
  
  error_log_filter <- reactive({
    "WHERE log_entry_time IS NOT NULL AND log_entry_time <> ''"
  })
  
  # ============================================================
  # TAB 0: TODAY'S URGENT ALERTS
  # ============================================================
  output$dt_urgent_alerts <- renderDataTable({
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    table_exists <- dbExistsTable(con_temp, "redcap_log_view")
    dbDisconnect(con_temp, shutdown = TRUE)
    if (!table_exists) return(NULL)
    
    today_string <- format(Sys.Date(), "%Y-%m-%d")
    
    query <- paste0("
      WITH daily_logs AS (
        SELECT
          ts as log_timestamp,
          username as user_context,
          ip,
          page,
          misc
        FROM redcap_log_view
        WHERE ts IS NOT NULL
          AND CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS DATE) = '", today_string, "'
      )

      SELECT
        log_timestamp as Alert_Timestamp,
        'CRITICAL' as Severity,
        'Honey-Pot URL Forgery Probing' as Incident_Type,
        user_context as User_Context,
        ip as Source_IP,
        CONCAT('Attempted unapproved access to: ', page) as Diagnostics
      FROM daily_logs
      WHERE (page LIKE '%ControlCenter/%' OR page LIKE '%UserRights/%')
        AND user_context NOT IN ('admin', 'site_admin')

      UNION ALL

      SELECT
        MAX(log_timestamp) as Alert_Timestamp,
        'HIGH' as Severity,
        'Brute Force Authentication Vector' as Incident_Type,
        'MULTIPLE_ACCOUNTS' as User_Context,
        ip as Source_IP,
        CONCAT('Suspicious login burst identified: ', COUNT(*), ' raw hits on index portal.') as Diagnostics
      FROM daily_logs
      WHERE page = 'index.php' AND misc LIKE '%login%'
      GROUP BY ip
      HAVING COUNT(*) >= 6

      UNION ALL

      SELECT
        MAX(log_timestamp) as Alert_Timestamp,
        'CRITICAL' as Severity,
        'Massive Data Harvest / Cross-Project Exfiltration' as Incident_Type,
        user_context as User_Context,
        'VARIES' as Source_IP,
        CONCAT('User pulled structural data extracts today. Metadata: ', ANY_VALUE(misc)) as Diagnostics
      FROM daily_logs
      WHERE misc LIKE '%Export%' OR misc LIKE '%Report%'
      GROUP BY user_context

      ORDER BY Alert_Timestamp DESC
    ")
    
    res <- run_query(query)
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE) |>
      formatStyle('Severity', target = 'row', backgroundColor = styleEqual(c('CRITICAL', 'HIGH'), c('#fcd2d2', '#ffe7cc')), fontWeight = 'bold')
  })
  
  # ============================================================
  # TAB 1: VALUE BOXES & MAIN LOG TRAFFIC
  # ============================================================
  output$box_total_transactions <- renderValueBox({
    val <- run_query(paste0("SELECT COUNT(*)::INTEGER as count FROM redcap_log_view ", unified_log_filter()))$count
    valueBox(format(val, big.mark=","), "Total Audited Events", icon = icon("list-ol"), color = "blue")
  })
  
  output$box_unique_users <- renderValueBox({
    val <- run_query(paste0("SELECT COUNT(DISTINCT username)::INTEGER as count FROM redcap_log_view ", unified_log_filter()))$count
    valueBox(format(val, big.mark=","), "Unique User Profiles", icon = icon("users"), color = "teal")
  })
  
  output$box_unique_ips <- renderValueBox({
    val <- run_query(paste0("SELECT COUNT(DISTINCT ip)::INTEGER as count FROM redcap_log_view ", unified_log_filter()))$count
    valueBox(format(val, big.mark=","), "Unique Source IPs", icon = icon("network-wired"), color = "aqua")
  })
  
  output$box_security_alerts <- renderValueBox({
    val <- run_query(paste0("SELECT COUNT(*)::INTEGER as count FROM redcap_log_view ", unified_log_filter(), " AND page = 'index.php'"))$count
    valueBox(format(val, big.mark=","), "Login Portal Actions", icon = icon("shield-alt"), color = "red")
  })
  
  output$plot_log_timeline <- renderPlotly({
    df <- run_query(paste0("
      SELECT 
        CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS DATE)::VARCHAR as log_date,
        COUNT(*)::INTEGER as daily_hits
      FROM redcap_log_view
      ", unified_log_filter(), "
      GROUP BY 1 ORDER BY 1 ASC
    "))
    if(nrow(df) == 0) return(NULL)
    p <- ggplot(df, aes(x = log_date, y = daily_hits, group = 1, text = paste("Date:", log_date, "<br>Hits:", format(daily_hits, big.mark=",")))) +
      geom_line(color = "#3c8dbc", size = 1) + geom_point(color = "#3c8dbc", size = 2) +
      theme_minimal() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) + labs(x = "Date", y = "Total Transactions")
    ggplotly(p, tooltip = "text")
  })
  
  output$plot_user_events <- renderPlot({
    df <- run_query(paste0("SELECT CAST(page AS VARCHAR) as Action, COUNT(*)::INTEGER as total FROM redcap_log_view ", unified_log_filter(), " GROUP BY 1 ORDER BY 2 DESC LIMIT 8"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = reorder(Action, total), y = total)) + geom_col(fill = "#00a65a") + coord_flip() + theme_minimal() + labs(x = "Page / Script", y = "Hits")
  })
  
  output$plot_top_users <- renderPlot({
    df <- run_query(paste0("SELECT CAST(username AS VARCHAR) as Account, COUNT(*)::INTEGER as total FROM redcap_log_view ", unified_log_filter(), " GROUP BY 1 ORDER BY 2 DESC LIMIT 10"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = reorder(Account, total), y = total)) + geom_col(fill = "#00c0ef") + coord_flip() + theme_minimal() + labs(x = "User ID Account", y = "Transactions")
  })
  
  output$plot_brute_force <- renderPlot({
    df <- run_query(paste0("SELECT CAST(ip AS VARCHAR) as Source_IP, COUNT(*)::INTEGER as Login_Attempts FROM redcap_log_view ", unified_log_filter(), " AND page = 'index.php' GROUP BY 1 ORDER BY 2 DESC LIMIT 10"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = reorder(Source_IP, Login_Attempts), y = Login_Attempts)) + geom_col(fill = "#dd4b39") + coord_flip() + theme_minimal() + labs(x = "Suspect IP Address", y = "Login Screen Hits")
  })
  
  output$plot_project_activity <- renderPlot({
    df <- run_query(paste0("SELECT 'PID ' || CAST(project_id AS VARCHAR) as Project, COUNT(*)::INTEGER as Event_Volume FROM redcap_log_view ", unified_log_filter(), " AND project_id IS NOT NULL GROUP BY 1 ORDER BY 2 DESC LIMIT 10"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = reorder(Project, Event_Volume), y = Event_Volume)) + geom_col(fill = "#f39c12") + coord_flip() + theme_minimal() + labs(x = "REDCap Project ID", y = "Transaction Volume")
  })
  
  output$dt_unified_logs <- renderDataTable({
    res <- run_query(paste0("SELECT ts as Timestamp, username as User_ID, ip as Source_IP, project_id as PID, page as Executed_Script, event as Action_Logged FROM redcap_log_view ", unified_log_filter(), " ORDER BY ts DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 25, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 2: HTTP TRAFFIC & NETWORK SECURITY MATRIX
  # ============================================================
  output$plot_http_codes <- renderPlot({
    df <- run_query(paste0("
      SELECT 
        CASE 
          WHEN LOWER(event) LIKE '%unprocessed%' OR LOWER(event) LIKE '%error%' THEN 'Flagged Interventions'
          WHEN LOWER(event) LIKE '%page view%' OR LOWER(event) LIKE '%view%' OR LOWER(event) LIKE '%render%' THEN 'Standard Reads'
          ELSE 'State Modifications'
        END as Status_Proxy, COUNT(*)::INTEGER as total 
      FROM redcap_log_view ", unified_log_filter(), " GROUP BY 1 ORDER BY 2 DESC"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = Status_Proxy, y = total, fill = Status_Proxy)) + geom_col() + theme_minimal() + labs(x = "Transaction Classification", y = "Count") + theme(legend.position="none")
  })
  
  output$plot_http_methods <- renderPlot({
    df <- run_query(paste0("
      SELECT 
        CASE 
          WHEN page LIKE '%API%' THEN 'API Call'
          WHEN page LIKE '%index.php%' THEN 'Authentication Payload'
          WHEN page LIKE '%Plugins%' OR page LIKE '%ExternalModules%' THEN 'Ext Module Traversal'
          ELSE 'Standard Base Request'
        END as Method_Proxy, COUNT(*)::INTEGER as total 
      FROM redcap_log_view ", unified_log_filter(), " GROUP BY 1 ORDER BY 2 DESC"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = reorder(Method_Proxy, total), y = total)) + geom_col(fill = "#605ca8") + coord_flip() + theme_minimal() + labs(x = "Inferred Request Profiling", y = "Volume")
  })
  
  output$dt_suspicious_ips <- renderDataTable({
    res <- run_query(paste0("
      SELECT ip as Suspicious_Source_IP, COUNT(*)::INTEGER as Total_Transactions, COUNT(DISTINCT project_id)::INTEGER as Projects_Accessed, COUNT(CASE WHEN page = 'index.php' THEN 1 END)::INTEGER as Login_Portal_Hits, MAX(ts) as Last_Seen_Activity
      FROM redcap_log_view ", unified_log_filter(), " AND ip IS NOT NULL AND ip != '127.0.0.1' AND ip NOT LIKE '172.%%' GROUP BY 1 ORDER BY Total_Transactions DESC LIMIT 100"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 3: EXPORTS & DOWNLOADS
  # ============================================================
  output$plot_export_timeline <- renderPlotly({
    df <- run_query(paste0("
      SELECT 
        CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS DATE)::VARCHAR as log_date, COUNT(*)::INTEGER as total_exports
      FROM redcap_log_view ", unified_log_filter(), " AND (event LIKE '%Data export%' OR page LIKE '%export%' OR page LIKE '%report%') GROUP BY 1 ORDER BY 1 ASC"))
    if(nrow(df) == 0) return(NULL)
    p <- ggplot(df, aes(x = log_date, y = total_exports, group = 1, text = paste("Date:", log_date, "<br>Exports:", format(total_exports, big.mark=",")))) +
      geom_area(fill = "#00c0ef", alpha = 0.4) + geom_line(color = "#00c0ef", size = 1) +
      theme_minimal() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) + labs(x = "Date Window", y = "Dataset Exports")
    ggplotly(p, tooltip = "text")
  })
  
  output$dt_downloads_ledger <- renderDataTable({
    res <- run_query(paste0("SELECT ts, username, ip, 'PID ' || CAST(project_id AS VARCHAR) as Project, event, page FROM redcap_log_view ", unified_log_filter(), " AND (event LIKE '%Data export%' OR page LIKE '%export%' OR page LIKE '%report%' OR page LIKE '%file_download%') ORDER BY ts DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 4: EXFILTRATION RISK MATRIX
  # ============================================================
  output$plot_exfil_outliers <- renderPlot({
    df <- run_query(paste0("SELECT CAST(username AS VARCHAR) as Risk_User, COUNT(*)::INTEGER as Export_Count FROM redcap_log_view ", unified_log_filter(), " AND (event LIKE '%Data export%' OR page LIKE '%export%') GROUP BY 1 ORDER BY 2 DESC LIMIT 8"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = reorder(Risk_User, Export_Count), y = Export_Count)) + geom_col(fill = "#dd4b39") + coord_flip() + theme_minimal() + labs(x = "User Account", y = "Extraction Count")
  })
  
  output$dt_exfil_matrix <- renderDataTable({
    res <- run_query(paste0("
      SELECT username as Target_User, ip as Vector_IP, COUNT(DISTINCT project_id)::INTEGER as Impacted_Projects, COUNT(CASE WHEN event LIKE '%Data export%' OR page LIKE '%export%' THEN 1 END)::INTEGER as Bulk_Export_Events, COUNT(*)::INTEGER as Total_Correlated_Actions, MAX(ts) as Last_Exfil_Signal
      FROM redcap_log_view ", unified_log_filter(), " AND ip NOT LIKE '172.%%' GROUP BY 1, 2 HAVING Bulk_Export_Events > 0 OR Total_Correlated_Actions > 100 ORDER BY Bulk_Export_Events DESC, Total_Correlated_Actions DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 5: IMPOSSIBLE TRAVEL / GEO-VELOCITY
  # ============================================================
  output$dt_impossible_travel <- renderDataTable({
    res <- run_query(paste0("
      WITH base_logs AS (
        SELECT username, ip, CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS TIMESTAMP) as event_time FROM redcap_log_view ", unified_log_filter(), " AND username IS NOT NULL AND ip IS NOT NULL AND ip != '127.0.0.1' AND ip NOT LIKE '172.%%'
      ), ordered_logs AS (
        SELECT username, ip as current_ip, event_time as current_time, LAG(ip) OVER (PARTITION BY username ORDER BY event_time) as prev_ip, LAG(event_time) OVER (PARTITION BY username ORDER BY event_time) as prev_time FROM base_logs
      )
      SELECT username as Targeted_Account, prev_ip as Prior_Location_IP, current_ip as Secondary_Location_IP, prev_time as Initial_Hit_Timestamp, current_time as Incompatible_Hit_Timestamp, EXTRACT(EPOCH FROM (current_time - prev_time))::INTEGER as Elapsed_Seconds FROM ordered_logs WHERE prev_ip IS NOT NULL AND current_ip != prev_ip AND (current_time - prev_time) < INTERVAL '1 hour' ORDER BY current_time DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 6: TEMPORAL ANOMALIES
  # ============================================================
  output$plot_hourly_distribution <- renderPlot({
    df <- run_query(paste0("SELECT EXTRACT(HOUR FROM CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS TIMESTAMP))::INTEGER as log_hour, COUNT(*)::INTEGER as transaction_count FROM redcap_log_view ", unified_log_filter(), " GROUP BY 1 ORDER BY 1 ASC"))
    if(nrow(df) == 0) return(NULL)
    ggplot(df, aes(x = log_hour, y = transaction_count)) + geom_bar(stat="identity", fill="#f39c12") + scale_x_continuous(breaks=0:23) + theme_minimal() + labs(x="Hour of Day (0-23)", y="Transactions Processing")
  })
  
  output$plot_daily_distribution <- renderPlot({
    df <- run_query(paste0("SELECT CASE EXTRACT(DOW FROM CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS TIMESTAMP))::INTEGER WHEN 0 THEN 'Sunday' WHEN 1 THEN 'Monday' WHEN 2 THEN 'Tuesday' WHEN 3 THEN 'Wednesday' WHEN 4 THEN 'Thursday' WHEN 5 THEN 'Friday' WHEN 6 THEN 'Saturday' END as day_name, COUNT(*)::INTEGER as transaction_count, EXTRACT(DOW FROM CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS TIMESTAMP))::INTEGER as day_idx FROM redcap_log_view ", unified_log_filter(), " GROUP BY 1, 3 ORDER BY day_idx ASC"))
    if(nrow(df) == 0) return(NULL)
    df$day_name <- factor(df$day_name, levels=c('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'))
    ggplot(df, aes(x = day_name, y = transaction_count)) + geom_col(fill="#605ca8") + theme_minimal() + labs(x="Day of Week", y="Transactions Processing")
  })
  
  output$dt_dark_hours_ledger <- renderDataTable({
    res <- run_query(paste0("
      SELECT ts as Incident_Timestamp, username as User_ID, ip as Source_IP, page as Executed_Script, event as Logged_Action FROM redcap_log_view ", unified_log_filter(), " 
      AND (EXTRACT(HOUR FROM CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS TIMESTAMP)) >= 22 OR EXTRACT(HOUR FROM CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS TIMESTAMP)) <= 5 OR EXTRACT(DOW FROM CAST(strptime(ts, '%Y-%m-%d %H:%M:%S') AS TIMESTAMP)) IN (0, 6)) ORDER BY ts DESC LIMIT 1000"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 7: SESSION INTEGRITY & API ABUSE
  # ============================================================
  output$dt_api_velocity <- renderDataTable({
    res <- run_query(paste0("SELECT username as API_Owner, ip as Endpoint_IP, COUNT(*)::INTEGER as API_Calls_Executed, COUNT(DISTINCT project_id)::INTEGER as Dynamic_PIDs_Hit, MIN(ts) as Burst_Start, MAX(ts) as Burst_End FROM redcap_log_view ", unified_log_filter(), " AND (page LIKE '%api%' OR page LIKE '%API%' OR event LIKE '%API%') GROUP BY 1, 2 HAVING API_Calls_Executed > 50 ORDER BY API_Calls_Executed DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  output$dt_concurrent_sessions <- renderDataTable({
    res <- run_query(paste0("SELECT username as Suspect_Account, COUNT(DISTINCT session_id)::INTEGER as Active_Token_Count, COUNT(DISTINCT ip)::INTEGER as Overlapping_IP_Footprints, GROUP_CONCAT(DISTINCT ip) as Network_Vectors FROM redcap_log_view ", unified_log_filter(), " AND username IS NOT NULL AND session_id IS NOT NULL AND session_id <> '' GROUP BY 1 HAVING Active_Token_Count > 1 OR Overlapping_IP_Footprints > 1 ORDER BY Active_Token_Count DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  output$dt_honeypot_probing <- renderDataTable({
    res <- run_query(paste0("SELECT ts as Target_Time, username as Intruder_Account, ip as Attacker_IP, page as Target_URL, event as Event_Context FROM redcap_log_view ", unified_log_filter(), " AND (page LIKE '%ControlCenter%' OR page LIKE '%UserRights%' OR page LIKE '%ViewAuth%' OR page LIKE '%add_users%') AND username NOT LIKE '%admin%' AND username NOT LIKE '%root%' ORDER BY ts DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 8: SYSTEM ALERTS SENT
  # ============================================================
  output$plot_alert_trends <- renderPlot({
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    table_exists <- dbExistsTable(con_temp, "redcap_alerts_sent_log")
    dbDisconnect(con_temp, shutdown = TRUE)
    if(!table_exists) return(NULL)
    
    df <- run_query(paste0("SELECT COALESCE(CAST(alert_type AS VARCHAR), 'Unknown Rule') as Alert_Rule, COUNT(*)::INTEGER as total FROM redcap_alerts_sent_log ", alert_log_filter(), " GROUP BY 1 ORDER BY 2 DESC LIMIT 10"))
    
    # Visual placeholder if there's no data in the chosen global date range
    if(nrow(df) == 0) {
      return(ggplot() + annotate("text", x = 1, y = 1, label = "No Automated Alerts Recorded\nin This Analysis Window", size = 5, fontface = "italic") + theme_void())
    }
    ggplot(df, aes(x = reorder(Alert_Rule, total), y = total)) + geom_col(fill = "#00a65a") + coord_flip() + theme_minimal() + labs(x = "Alert Type", y = "Dispatches")
  })
  
  output$plot_alert_targets <- renderPlot({
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    table_exists <- dbExistsTable(con_temp, "redcap_alerts_sent_log")
    dbDisconnect(con_temp, shutdown = TRUE)
    if(!table_exists) return(NULL)
    
    df <- run_query(paste0("SELECT COALESCE(CAST(alert_target AS VARCHAR), 'System Loop') as Recipient, COUNT(*)::INTEGER as total FROM redcap_alerts_sent_log ", alert_log_filter(), " GROUP BY 1 ORDER BY 2 DESC LIMIT 8"))
    
    if(nrow(df) == 0) {
      return(ggplot() + annotate("text", x = 1, y = 1, label = "No Notification Destinations Found", size = 5, fontface = "italic") + theme_void())
    }
    ggplot(df, aes(x = reorder(Recipient, total), y = total)) + geom_col(fill = "#f39c12") + coord_flip() + theme_minimal() + labs(x = "Recipient Routing", y = "Alerts Sent")
  })
  
  output$dt_alert_logs <- renderDataTable({
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    table_exists <- dbExistsTable(con_temp, "redcap_alerts_sent_log")
    dbDisconnect(con_temp, shutdown = TRUE)
    if(!table_exists) return(NULL)
    
    res <- run_query(paste0("SELECT time_sent as Dispatched_Timestamp, alert_id as Log_ID, alert_type as Rule_ID, alert_target as Recipient_Routing, alert_message as Message_Snippet FROM redcap_alerts_sent_log ", alert_log_filter(), " ORDER BY time_sent DESC"))
    datatable(res, extensions = 'Buttons', options = list(pageLength = 10, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
  
  # ============================================================
  # TAB 9: SYSTEM ERRORS (Multi-Format Time Processor)
  # ============================================================
  output$plot_error_trends <- renderPlotly({
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    table_exists <- dbExistsTable(con_temp, "server_error_logs")
    dbDisconnect(con_temp, shutdown = TRUE)
    if(!table_exists) return(NULL)
    
    # Using try_strptime avoids database panic crashes if an unexpected row format sneaks through.
    df <- run_query("
      SELECT 
        CAST(
          COALESCE(
            try_strptime(SUBSTR(log_entry_time, 2, LENGTH(log_entry_time) - 2), '%a %b %d %H:%M:%S.%f %Y'),
            try_strptime(REGEXP_REPLACE(log_entry_time, ' UTC$', ''), '%d-%b-%Y %H:%M:%S')
          )
        AS DATE)::VARCHAR as error_date,
        COUNT(*)::INTEGER as total_errors
      FROM server_error_logs
      WHERE log_entry_time IS NOT NULL 
        AND log_entry_time <> ''
        AND LENGTH(log_entry_time) > 10
      GROUP BY 1 
      HAVING error_date IS NOT NULL
      ORDER BY 1 ASC")
    
    if(nrow(df) == 0) {
      return(ggplot() + annotate("text", x = 1, y = 1, label = "No Historical PHP System Errors Found", size = 5, fontface = "italic") + theme_void())
    }
    
    p <- ggplot(df, aes(x = error_date, y = total_errors, group = 1, text = paste("Date:", error_date, "<br>Errors:", format(total_errors, big.mark=",")))) +
      geom_line(color = "#dd4b39", size = 1) + geom_point(color = "#dd4b39", size = 2) +
      theme_minimal() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) + labs(x = "Date Window", y = "PHP Exceptions")
    ggplotly(p, tooltip = "text")
  })
  
  output$dt_error_logs <- renderDataTable({
    con_temp <- dbConnect(duckdb(), dbdir = db_path, read_only = TRUE)
    table_exists <- dbExistsTable(con_temp, "server_error_logs")
    dbDisconnect(con_temp, shutdown = TRUE)
    if(!table_exists) return(NULL)
    
    res <- run_query("
      SELECT 
        log_entry_time as Error_Timestamp, 
        error_details as Error_Message_Detail 
      FROM server_error_logs 
      WHERE log_entry_time IS NOT NULL AND log_entry_time <> ''
      ORDER BY log_entry_time DESC 
      LIMIT 1000")
    
    datatable(res, extensions = 'Buttons', options = list(pageLength = 15, scrollX = TRUE, dom = 'Bfrtip', buttons = list('csv', 'excel')), rownames = FALSE)
  })
}

shinyApp(ui, server)